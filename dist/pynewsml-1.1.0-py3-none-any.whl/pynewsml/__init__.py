from pynewsml.newsml import NewsML, NewsItem
